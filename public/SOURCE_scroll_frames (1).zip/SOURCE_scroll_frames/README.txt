SOURCE scroll-controlled frame sequence

30 individual 960x540 WebP images, with no text overlays.
Files are named frame_001.webp through frame_030.webp.
Place the frames in your React public/frames/ directory.
Note: these are extracted from a generated storyboard image, so transitions are approximate, not true original video frames.
